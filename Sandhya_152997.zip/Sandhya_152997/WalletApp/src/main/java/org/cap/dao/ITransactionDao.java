package org.cap.dao;

import java.util.Date;
import java.util.List;

import org.cap.model.Transaction;

public interface ITransactionDao {

	public void createTransaction(Transaction transaction);
	public List<Transaction> getTransactions(Integer custId);
	public List<Transaction> getDatedTransactions(Integer customerId, Date d1, Date d2);
	public List<Transaction> getDatedTransactions(Integer customerId, Date d1);
}
