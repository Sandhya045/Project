package org.cap.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day7PilotImplApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day7PilotImplApplication.class, args);
	}
}
