package org.cap.controller;

import java.util.List;

import org.cap.model.Hotel;
import org.cap.service.IBookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BookingController {
	
	@Autowired
	private IBookingService bookingService;
	
	
	private String hname;
	
	@RequestMapping("/")
	public String getHotelDetails(ModelMap map) {
		List<Hotel> hotels=bookingService.getAll();
		map.put("hotels", hotels);
		return "HotelDetails";
	}
	
	@GetMapping("/book/{hotelName}")
	public String bookHotel(@PathVariable("hotelName")String name) {
		hname=name;
		return "HotelBooking";
	}
	
	@RequestMapping("/book/booking/Confirm")
	public String confirmPage(ModelMap map) {
		map.put("hotelname", hname);
		return "BookingConfirmation";
	}

}
