package org.cap.dao;

import java.util.List;

import org.cap.model.Hotel;

public interface IBookingDAO {

	public List<Hotel> getAll();

}
