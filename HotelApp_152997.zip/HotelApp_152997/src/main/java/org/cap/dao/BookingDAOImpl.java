package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Hotel;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("bookingDAO")
@Transactional
public class BookingDAOImpl implements IBookingDAO {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Hotel> getAll() {
		
		List<Hotel> hotels=entityManager.createQuery("from Hotel").getResultList();
		return hotels;
	}

}
