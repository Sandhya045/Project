package org.cap.service;

import java.util.List;

import org.cap.dao.IBookingDAO;
import org.cap.model.Hotel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("bookingService")
public class BookingServiceImpl implements IBookingService {
	
	@Autowired
	private IBookingDAO bookingDAO;

	@Override
	public List<Hotel> getAll() {
		
		return bookingDAO.getAll();
	}

}
