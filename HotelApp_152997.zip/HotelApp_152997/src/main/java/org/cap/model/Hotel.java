package org.cap.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hoteldetails")
public class Hotel {

	@Id
	@GeneratedValue
	@Column(name="id")
	private int hotelId;
	
	@Column(name="name")
	private String hotelName;
	
	@Column(name="rating")
	private String hotelRating;
	
	@Column(name="rate")
	private double rate;
	
	@Column(name="availablerooms")
	private int availRooms;

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getHotelRating() {
		return hotelRating;
	}

	public void setHotelRating(String hotelRating) {
		this.hotelRating = hotelRating;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public int getAvailRooms() {
		return availRooms;
	}

	public void setAvailRooms(int availRooms) {
		this.availRooms = availRooms;
	}

	public Hotel(int hotelId, String hotelName, String hotelRating, double rate, int availRooms) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.hotelRating = hotelRating;
		this.rate = rate;
		this.availRooms = availRooms;
	}

	public Hotel() {
		
		super();
		
	}

	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", hotelRating=" + hotelRating + ", rate="
				+ rate + ", availRooms=" + availRooms + "]";
	}
	
	
	
	
}
