package com.cg.productmgmt.service;

import java.util.Map;

import com.cg.productmgmt.dao.IProductDao;
import com.cg.productmgmt.dao.ProductDao;
import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService {
IProductDao productDao=new ProductDao();
	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		// TODO Auto-generated method stub
		return productDao.updateProducts(Category,hike);
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		// TODO Auto-generated method stub
		return productDao.getProductDetails();
	}	
}
