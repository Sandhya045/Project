package com.cg.productmgmt.dao.test;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;

import com.cg.productmgmt.dao.IProductDao;
import com.cg.productmgmt.dao.ProductDao;
import com.cg.productmgmt.exception.ProductException;

public class ProductDaoTest {
	IProductDao p=new ProductDao();
	
	@Test
	public void testUpdateProducts() throws ProductException {
		try {
			p.updateProducts("pen", 5);
		} catch (Exception e)
		{
			throw new ProductException();
		}
	}

	@Test
	public void testGetProductDetails() {
		try {
			assertNotNull(p.getProductDetails());
			
		}catch(ProductException e) {
			e.printStackTrace();
		}
	}

}
