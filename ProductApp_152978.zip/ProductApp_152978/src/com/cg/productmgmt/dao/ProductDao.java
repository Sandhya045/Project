package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
/**
 * Class			:	ProductDao
 * Author			:	Vignesh
 * Date				: 	4th July,2018
 * Purpose			:	Data Manipulation of Associated Source
 * No. of methods 	:	2
 */

import com.cg.productmgmt.exception.ProductException;

public class ProductDao implements IProductDao {
	String temp;
static Map<String, String> productDetails;
static Map<String, Integer> salesDetails;
static {
	productDetails=new HashMap<>();
	productDetails.put("lux", "soap");
	productDetails.put("colgate", "paste");
	productDetails.put("pears", "soap");
	productDetails.put("sony", "electronics");
	productDetails.put("samsung", "electronics");
	productDetails.put("facepack", "cosmatics");
	productDetails.put("facecream", "cosmatics");
	
	salesDetails=new HashMap<>();
	salesDetails.put("lux", 100);
	salesDetails.put("colgate", 50);
	salesDetails.put("pears", 70);
	salesDetails.put("sony", 10000);
	salesDetails.put("samsung", 23000);
	salesDetails.put("facepack", 100);
	salesDetails.put("facecream", 60);
}
/**
 * Method Name		:	updateProducts
 * Parameters		:	2
 * Return Type		:	Integer
 * Purpose			:	Updates Price of products
 * Author			:	Vignesh
 * Date of Creation :	4th July,2018
 * Last Modified	:	4th July,2018
 */
	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		
			Set<String> products=new HashSet<String>();
			Set<String> keys=productDetails.keySet();
			String value=null;
			int nePrice=0;
			int updated=0;
			boolean isUpdated=false;
			for(String key:keys) {
				value=productDetails.get(key);
				if(value.equals(Category)) {
					products.add(key);
				}
			}
			Set<String> keySales=salesDetails.keySet();
			for(String sale:keySales) {
				if(products.contains(sale)) {
					nePrice=salesDetails.get(sale);
					nePrice+=hike;
					salesDetails.put(sale, nePrice);
					updated=1;
				}
			}
			return updated;
	} 
	/**
	 * Method Name		:	getProductDetails
	 * Parameters		:	nil
	 * Return Type		:	Map
	 * Purpose			:	Displays product lists
	 * Author			:	Vignesh
	 * Date of Creation :	4th July,2018
	 * Last Modified	:	4th July,2018
	 */

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		// TODO Auto-generated method stub
		return salesDetails;
	}

}
