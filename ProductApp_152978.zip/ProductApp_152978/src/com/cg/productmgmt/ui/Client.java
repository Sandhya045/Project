package com.cg.productmgmt.ui;

import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;

public class Client {
	Scanner scan=new Scanner(System.in);
	String category;
	int hike;
	IProductService productService=new ProductService();
	public static void main(String[] args) {
		Client c=new Client();
		String option=null;
		while(true) {
		System.out.println("------------Product Updation-------------");
		System.out.println("1.Update Product Price");
		System.out.println("2.Display Product List");
		System.out.println("3.Exit");
		System.out.println("Enter your choice");
		option=c.scan.nextLine();
		switch(option) {
		case "1":
			c.updateRequest();
			break;
		case "2":
			c.displayRequest();
			break;
		case "3":
			System.exit(0);
			break;
		default:
			System.out.println("Enter valid option from 1 to 3");
			break;
		}
		}
	}
	private void updateRequest() {
		try {
		System.out.println("Enter the Product Category");
		category=scan.nextLine();
		System.out.println("Enter the hike in product Category");
		hike=Integer.parseInt(scan.nextLine());
		int ret=productService.updateProducts(category, hike);
		if(ret==1)
			{
				System.out.println("Product Price Update successfully for "+category+" by "+hike+"");
			}
		}
		catch(ProductException ex) {
			System.out.println();
			System.err.println("An error occured :" +ex.getMessage());
			System.out.println();
		}
	}
	public void displayRequest() {
		
		try {
			Map<String,Integer> productDetails=productService.getProductDetails();
			Set set=productDetails.entrySet();
			set.stream().forEach(System.out::println);
		}
		catch(ProductException e) {
			System.err.println("An error occured" +e.getMessage());
		}
	}
}