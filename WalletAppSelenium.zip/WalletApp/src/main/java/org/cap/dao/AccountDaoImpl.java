package org.cap.dao;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("accountDao")
public class AccountDaoImpl implements IAccountDao {
	
	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	private EntityManager entityManager;
	
	@Autowired
	private ILoginService loginService; 
	
	@Override
	@Transactional
	public void createAccount(Account account) {
		
		Query query= entityManager.createQuery("select max(accountNo) from Account");
		
		List<Long> max= query.getResultList();
		
		account.setAccountNo(max.get(0)+1);
		
		//System.out.println(account);
		
		entityManager.persist(account);
		
	}

	@Override
	@Transactional(readOnly=true)
	public List<Account> getAllAccounts(int customerId) {
		
		Query query= entityManager
			.createQuery("from Account acc where acc.customer.customerId=:custId");
		
		query.setParameter("custId", customerId);
		
		
		List<Account> accounts= query.getResultList();
		
		
		return accounts;
	}
	
	@Override
	@Transactional(readOnly=true)
	public List<Account> getAccounts(int customerId) {
		
		Query query= entityManager
			.createQuery("from Account acc where acc.customer.customerId!=:custId");
		
		query.setParameter("custId", customerId);
		
		
		List<Account> accounts= query.getResultList();
		
		
		return accounts;
	}
	
	@Transactional(readOnly=true)
	public Map<Account, Double> getAmoutCrDe(String strQuery,int customerId){
	
		
		Query query2=entityManager
				.createQuery(strQuery);
		
		query2.setParameter("custId", customerId);
		
		List<Transaction> transactions=query2.getResultList();
		Map<Account, Double> map=
		transactions.stream()
				.collect(
				Collectors.groupingBy(Transaction::getFromAccount,
					Collectors.summingDouble(Transaction::getAmount))
				);
		return map;
	}
	
	@Override
	@Transactional(readOnly=true)
	public int getCustId(int accountId) {
		
		Query query= entityManager
			.createQuery("select acc.customer.customerId from Account acc where acc.accountId=:accId");
		
		query.setParameter("accId", accountId);
		List<Integer> cId= query.getResultList();
		
		return cId.get(0);
	}

	@Override
	public Account findAccount(int accId) {
		
		//Query query= entityManager.createQuery("from Account acc where acc.accountNo=:accNo");
		Account account=entityManager.find(Account.class, accId);
		
		return account;
	}
		
	
	public void fundTransfer(Transaction transaction) {
		
		entityManager.persist(transaction);
		
		int custId=getCustId(transaction.getToAccount().getAccountId());
		
		Transaction transaction2=new Transaction();
		transaction2.setTransactionType("credit");
		transaction2.setCustomer(loginService.findCustomer(custId));
		transaction2.setAmount(transaction.getAmount());
		transaction2.setFromAccount(transaction.getFromAccount());
		transaction2.setToAccount(transaction.getToAccount());
		transaction2.setStatus(transaction.getStatus());
		transaction2.setTransactionDate(transaction.getTransactionDate());
		transaction2.setDescription(transaction.getDescription());
		
		entityManager.persist(transaction2);
	}
	
}
 