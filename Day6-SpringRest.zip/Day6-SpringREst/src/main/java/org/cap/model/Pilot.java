package org.cap.model;

import java.util.Date;


import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;


public class Pilot {
	
	private int pilotId;
	//@NotEmpty(message="*please enter firstName.")
	private String firstName;
	private String lastName;
	
	//@NotNull(message="* Please enter Date Of Birth.")
	//@Past(message="* Please enter past date.")
	private Date dateOfBirth;
	
	//@Future(message="* Please nter future date.")
	private Date dateOfJoin;
	private Boolean isCertified;
	
//	@Range(min=10000,max=200000,message="*Salary should be between 10000 and 2laks.")
	private double salary;
	
	public Pilot() {
		
	}
	

	public Pilot(int pilotId, String firstName, String lastName, Date dateOfBirth, Date dateOfJoin, Boolean isCertified,
			double salary) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.dateOfJoin = dateOfJoin;
		this.isCertified = isCertified;
		this.salary = salary;
	}


	public Date getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public int getPilotId() {
		return pilotId;
	}
	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public Date getDateOfJoin() {
		return dateOfJoin;
	}


	public void setDateOfJoin(Date dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}


	public Boolean getIsCertified() {
		return isCertified;
	}

	public void setIsCertified(Boolean isCertified) {
		this.isCertified = isCertified;
	}

	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
				+ dateOfBirth + ", dateOfJoin=" + dateOfJoin + ", isCertified=" + isCertified + ", salary=" + salary
				+ "]";
	}
	
	
	

}
